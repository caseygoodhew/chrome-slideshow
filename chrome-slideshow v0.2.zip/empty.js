setTimeout(function() {
	window.location = "options.html";
}, 1000);

